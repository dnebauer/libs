* TODO [2015-01-03 Sat] deskdet: Window manager information
* TODO [2015-01-03 Sat] deskdet: Detect Windows?
* TODO [2015-01-03 Sat] deskdet: XFCE: version
* TODO [2015-01-03 Sat] deskdet: Detect MATE
* TODO [2015-01-03 Sat] deskdet: Detect Unity
* TODO [2015-01-03 Sat] deskdet: Detect JWM
